from tkinter import *           #import z biblioteki
from tkinter import messagebox  #import z biblioteki
import random as r              #import losowej z biblioteki


def button(frame):                          #Funkcja definiująca przyciski
    b = Button(frame,                       #przypisanie przycisku
               bg="#24a9ad",                #kolor tła
               width=3, text="",            #szerokość komórki ,wypełnienie tekstowe komórki
               font=('arial', 80,),         #czcionka ,rozmiar komórki
               relief='sunken',bd=2)        #rodzaj obramowania
    return b







                                                                                #Pętla wyżej sprawdzająca remis jesli nikt nie wygra





root = Tk()
root.title("Kółko i krzyżyk")
a = r.choice(['X', 'O'])
colour = {'O': "#e8dfc3", 'X': "#545044"}
b = [[], [], []]

for i in range(3):
    for j in range(3):
        b[i].append(button(root))
        b[i][j].config(command=lambda row=i, col=j: click(row, col))
        b[i][j].grid(row=i, column=j)
label = Label(text="Ruch gracza " + a , font=('arial', 10,'bold'))
label.grid(row=3, column=0, columnspan=3)
root.mainloop()
